from django.http import HttpResponse
from django.shortcuts import redirect, render, get_object_or_404
from django.contrib.auth.forms import AuthenticationForm
from .forms import CustomUserCreationForm
from django.contrib.auth import login, logout
from .models import Pet  # Adjust this import according to your models

def register_view(request):
    errors = None
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
        else:
            errors = form.errors.as_data()
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form, 'errors': errors})

def login_view(request):
    errors = None
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('/')  # Change to your desired landing page after login
        else:
            errors = form.errors.as_data()
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form, 'errors': errors})

def logout_view(request):
    if request.method == 'POST':
        logout(request)
        return redirect('/')  # Change to your desired landing page after logout

def index(request):
    # Add logic to retrieve and display pets or any other data for the home page
    return render(request, 'index.html')  # Adjust the template name as needed

def singlepet(request, pet_id):
    pet = get_object_or_404(Pet, id=pet_id)  # Retrieve the pet by ID
    return render(request, 'singlepet.html', {'pet': pet})  # Adjust the template name as needed

def pet_create(request):
    # Logic for creating a new pet listing goes here
    return render(request, 'pet_create.html')  # Adjust the template name as needed

def pet_update(request, pet_id):
    # Logic for updating an existing pet listing goes here
    return render(request, 'pet_update.html')  # Adjust the template name as needed

def pet_delete(request, pet_id):
    # Logic for deleting a pet listing goes here
    return redirect('all_pets_view')  # Redirect after deletion

def self_profile_view(request):
    # Logic to display user profile
    return render(request, 'self_profile.html')  # Adjust the template name as needed

def profile_view(request, user_id):
    # Logic to display another user's profile
    return render(request, 'profile.html')  # Adjust the template name as needed

def all_pets_view(request):
    pets = Pet.objects.all()  # Retrieve all pets
    return render(request, 'all_pets.html', {'pets': pets})  # Adjust the template name as needed

def adopt(request, pet_id):
    # Logic for adopting a pet goes here
    return redirect('singlepet', pet_id=pet_id)  # Redirect after adoption process

def myadoptions(request):
    # Logic to display adopted pets goes here
    return render(request, 'my_adoptions.html')  # Adjust the template name as needed
